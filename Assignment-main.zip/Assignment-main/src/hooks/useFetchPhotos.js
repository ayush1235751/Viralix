import { useState, useEffect } from 'react';

function useFetchPhotos() {
  const [photos, setPhotos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();

    async function fetchPhotos() {
      try {
        setLoading(true);
        setError(null);
        const response = await fetch(
          'https://picsum.photos/v2/list?limit=30',
          { signal: controller.signal }
        );
        if (!response.ok) {
          throw new Error(`Failed to fetch photos: ${response.status}`);
        }
        const data = await response.json();
        setPhotos(data);
      } catch (err) {
        if (err.name !== 'AbortError') {
          setError(err.message || 'Something went wrong. Please try again.');
        }
      } finally {
        setLoading(false);
      }
    }

    fetchPhotos();

    // Cleanup: abort the fetch if the component unmounts
    return () => controller.abort();
  }, []);

  return { photos, loading, error };
}

export default useFetchPhotos;
