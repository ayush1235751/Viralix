import { useFavourites } from '../context/FavouritesContext';

function PhotoCard({ photo }) {
  const { favourites, toggleFavourite } = useFavourites();
  const isFavourite = favourites.has(photo.id);

  return (
    <div className="photo-card">
      <div className="photo-img-wrap">
        <img
          src={`https://picsum.photos/id/${photo.id}/400/300`}
          alt={photo.author}
          className="photo-img"
          loading="lazy"
        />
        <button
          onClick={() => toggleFavourite(photo.id)}
          className={`fav-btn${isFavourite ? ' active' : ''}`}
          aria-label={isFavourite ? 'Remove from favourites' : 'Add to favourites'}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill={isFavourite ? 'currentColor' : 'none'}
            stroke="currentColor"
            strokeWidth="2"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z"
            />
          </svg>
        </button>
      </div>
      <div className="card-footer">
        <div className="author-avatar">
          {photo.author.charAt(0).toUpperCase()}
        </div>
        <p className="author-name">{photo.author}</p>
      </div>
    </div>
  );
}

function Gallery({ photos }) {
  if (photos.length === 0) {
    return (
      <div className="empty-state">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <p>No photos match your search.</p>
        <span>Try a different author name.</span>
      </div>
    );
  }

  return (
    <div className="gallery-grid">
      {photos.map((photo) => (
        <PhotoCard key={photo.id} photo={photo} />
      ))}
    </div>
  );
}

export default Gallery;
