import { createContext, useContext, useReducer, useEffect } from 'react';

// --- Reducer ---
// Manages the favourites list as a Set of photo IDs
function favouritesReducer(state, action) {
  switch (action.type) {
    case 'TOGGLE_FAVOURITE': {
      const newFavourites = new Set(state);
      if (newFavourites.has(action.payload)) {
        newFavourites.delete(action.payload);
      } else {
        newFavourites.add(action.payload);
      }
      return newFavourites;
    }
    default:
      return state;
  }
}

// --- Helper: Load initial state from localStorage ---
function getInitialFavourites() {
  try {
    const stored = localStorage.getItem('favourites');
    if (stored) {
      return new Set(JSON.parse(stored));
    }
  } catch {
    // ignore parse errors
  }
  return new Set();
}

// --- Context ---
const FavouritesContext = createContext(null);

export function FavouritesProvider({ children }) {
  const [favourites, dispatch] = useReducer(
    favouritesReducer,
    undefined,
    getInitialFavourites
  );

  // Persist to localStorage whenever favourites change
  useEffect(() => {
    localStorage.setItem('favourites', JSON.stringify([...favourites]));
  }, [favourites]);

  function toggleFavourite(id) {
    dispatch({ type: 'TOGGLE_FAVOURITE', payload: id });
  }

  return (
    <FavouritesContext.Provider value={{ favourites, toggleFavourite }}>
      {children}
    </FavouritesContext.Provider>
  );
}

// --- Custom hook for consuming context ---
export function useFavourites() {
  const context = useContext(FavouritesContext);
  if (!context) {
    throw new Error('useFavourites must be used within a FavouritesProvider');
  }
  return context;
}
