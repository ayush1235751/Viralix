import { useState, useCallback, useMemo } from 'react';
import { FavouritesProvider } from './context/FavouritesContext';
import useFetchPhotos from './hooks/useFetchPhotos';
import Gallery from './components/Gallery';
import SearchBar from './components/SearchBar';

function AppContent() {
  const { photos, loading, error } = useFetchPhotos();
  const [searchQuery, setSearchQuery] = useState('');

  // useCallback memoises the handler so it's not recreated on every render
  const handleSearchChange = useCallback((value) => {
    setSearchQuery(value);
  }, []);

  // useMemo recomputes the filtered list only when photos or searchQuery change
  const filteredPhotos = useMemo(() => {
    if (!searchQuery.trim()) return photos;
    const query = searchQuery.toLowerCase();
    return photos.filter((photo) =>
      photo.author.toLowerCase().includes(query)
    );
  }, [photos, searchQuery]);

  return (
    <div>
      {/* Header */}
      <header className="header">
        <div className="header-inner">
          <div className="brand">
            <div className="brand-icon">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
              </svg>
            </div>
            <h1 className="brand-title">Photo Gallery</h1>
          </div>
          <SearchBar searchQuery={searchQuery} onSearchChange={handleSearchChange} />
        </div>
      </header>

      {/* Main */}
      <main className="main">
        {!loading && !error && (
          <div className="stats-bar">
            Showing{' '}
            <span className="count">{filteredPhotos.length}</span> of{' '}
            <strong>{photos.length}</strong> photos
            {searchQuery && (
              <span> &mdash; results for &quot;<span className="query-text">{searchQuery}</span>&quot;</span>
            )}
          </div>
        )}

        {loading && (
          <div className="loading-container">
            <div className="spinner" />
            <p className="loading-text">Loading photos…</p>
          </div>
        )}

        {error && !loading && (
          <div className="error-box">
            <div className="error-icon-wrap">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            <h2 className="error-title">Failed to load photos</h2>
            <p className="error-msg">{error}</p>
          </div>
        )}

        {!loading && !error && <Gallery photos={filteredPhotos} />}
      </main>
    </div>
  );
}

function App() {
  return (
    <FavouritesProvider>
      <AppContent />
    </FavouritesProvider>
  );
}

export default App;
